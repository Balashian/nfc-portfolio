<?php
if (basename($_SERVER["PHP_SELF"]) == basename(__FILE__)) {
    header("Location: index.php");
    exit();
}
$host = "localhost";
$dbname = "link_in_bio";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>