<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <script src="https://kit.fontawesome.com/beb9a053e4.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../main.css">
    <script src="../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body style="background-color: #151521;" class="text-white">
    <div class="container min-vh-100 d-flex justify-content-center align-items-center">
        <form autocomplete="off" action="login/login.php" method="post" style="background-color: #1e1e2d;" class="p-3 rounded-2 shadow-lg">
            <div class="mb-3">
                <label for="login_InputUserName1" class="form-label">Username</label>
                <input type="text" name="user_name" style="background-color: #1b1b29; color: white; border: 0px;" class="form-control" id="login_InputUserName1"
                    aria-describedby="userNameHelp" required>
            </div>
            <div class="mb-3">
                <label for="login_InputPassword1" class="form-label">Password</label>
                <input type="password" name="password" style="background-color: #1b1b29; color: white; border: 0px;" class="form-control" id="login_InputPassword1" required>
            </div>
            <button type="submit" class="btn btn-primary">Sign In</button>
            <div id="wrongHelp" class="form-text text-danger text-center">
                <?php
                if (isset($_GET["error"])){
                    echo $_GET["error"];
                }
                ?>
                </div>
            </form>
        </div>
    </body>

    </html>