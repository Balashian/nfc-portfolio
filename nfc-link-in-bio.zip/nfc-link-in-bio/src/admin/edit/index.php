<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/beb9a053e4.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../main.css">
    <script src="../../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>

<body style="padding-top: 56px; background-color: #151521;">
    <nav style="background-color: #1e1e2d;" class="navbar navbar-expand navbar-dark fixed-top">
        <div class="container-fluid">
            <a style="color: gold;" class="navbar-brand" href="#">
                Link in Bio
            </a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link ms-lg-2 text-danger" href="../login/logout.php"><i
                                class="fa-solid fa-power-off"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container col-sm-8 col-md-6 col-xl-5">
        <div style="background-color: #1e1e2d;" class="container my-5 px-4 py-5 rounded-3">
            <div class="input-group mb-3 p-0 border rounded">
                <div class="input-group-text border-0" style="background-color: #1e1e2d;">
                    <input style="background-color: #1b1b29; border: 3px solid #393b42;" class="form-check-input" type="checkbox" value="">
                </div>
                <input style="background-color: #1b1b29;" type="text" class="form-control border-0">
            </div>



        </div>
    </div>

</body>

</html>